//header file for communication module

#define COMM

#define URL "http://www.cc.puv.fi/~e1601122/php/raspsound.php"

//function prototype
void send_data(double []);
